using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadSceneManager : MonoBehaviour
{
    [SerializeField] private GameObject[] o;

    private void Awake()
    {
        for (int i = 0; i < o.Length; i++)
        {
            DontDestroyOnLoad(o[i]);
        }
        SceneController.Instance.LoadScene("MainScene");
    }
}
