using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;

public class PlayerController : MonoBehaviourPun
{
    Animator anim;

    private float run = 4.5f;
    private float speed = 6f;
    private float jump = 30f;
    private float distance = 10f;

    private CharacterController controller;
    private float angleX, angleY, gravityY;
    private Vector3 moveDir;
    private float horizontal, vertical;

    int ignoreLayer;

    private bool useStamina = false;
    private float staminaMaxValue = 5f;
    private float staminaCurrentValue = 5f;
    private float staminaCostValue = 1f;
    private float staminaRegenValue = .5f;

    private void Awake()
    {
        ignoreLayer = ~((1 << gameObject.layer) | (1 << LayerMask.NameToLayer("Player")));
        anim = GetComponent<Animator>();
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        Controller();
        Stamina();
    }

    private void Stamina()
    {
        if (useStamina)
        {
            staminaCurrentValue -= Time.deltaTime * staminaCostValue;
        }
        else
        {
            staminaCurrentValue += Time.deltaTime * staminaRegenValue;
        }
        staminaCurrentValue = Mathf.Clamp(staminaCurrentValue, 0, staminaMaxValue);
        float value = staminaCurrentValue / staminaMaxValue;
        InGameUIManager.Instance.RefreshStaminaGauge(value);
    }

    private void Controller() 
    { 
        angleX -= Input.GetAxis("Mouse Y");
        angleY += Input.GetAxis("Mouse X");
        Camera.main.transform.rotation = Quaternion.Euler(angleX, angleY, 0);

        Vector3 pivot = controller.bounds.center + Vector3.up * 1.2f;
        Vector3 direction = Quaternion.Euler(angleX, angleY, 0) * -Vector3.forward;
        float dis = distance;

        if (Physics.Raycast(pivot, direction, out RaycastHit hit, distance, ignoreLayer))
        {
            dis = hit.distance * .98f;
        }

        Camera.main.transform.position = pivot + Quaternion.Euler(angleX, angleY, 0) * -Vector3.forward * dis;

        transform.rotation = Quaternion.Euler(0, angleY, 0);

        horizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");

        bool isGrounded = controller.isGrounded || Physics.Raycast(controller.bounds.center, Vector3.down, controller.bounds.extents.y + controller.skinWidth + .8f, ignoreLayer);
        
        moveDir = Quaternion.Euler(0, angleY, 0) * new Vector3(horizontal, 0, vertical);
        if (moveDir.magnitude > 1) moveDir.Normalize();
        moveDir *= speed;

        if (isGrounded)
        {
            if (Physics.Raycast(controller.bounds.center, Vector3.down, controller.bounds.extents.y + controller.skinWidth + .02f, ignoreLayer))
            {
                gravityY = .0f;
                if (Input.GetKey(KeyCode.Space)) gravityY = jump;
            }

          

            if (Input.GetKey(KeyCode.LeftShift))
            {
                if (vertical > 0)
                {
                    useStamina = true;
                    if (staminaCurrentValue > 1)
                    {
                        moveDir *= run;
                    }
                    
                }
                else
                {
                    useStamina = false;
                }
            }
            else
            {
                useStamina = false;
            }

            anim.SetBool("isGrounded", true);
        }
        else
        {
            anim.SetBool("isGrounded", false);
        }
        anim.SetBool("moveForward", vertical > 0);
        anim.SetBool("moveBackward", vertical < 0);
        anim.SetBool("moveRight", horizontal > 0);
        anim.SetBool("moveLeft", horizontal < 0);

        anim.SetFloat("speed", moveDir.magnitude / speed);

        gravityY += Physics.gravity.y * Time.deltaTime;
        moveDir.y = gravityY;

        controller.Move(moveDir * Time.deltaTime);
        Punch();
        if (Input.GetKeyDown(KeyCode.F5))
        {
            SetDie();
        }
    }

    private void Punch()
    {
        bool punchable = !(anim.GetBool("punchLeft") || anim.GetBool("punchRight"));
        if (punchable)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (Random.Range(0f, 1f) < .5f)
                {
                    anim.SetBool("punchLeft", true);
                }
                else
                {
                    anim.SetBool("punchRight", true);
                }
            }
        }
    }

    private void SetPunch()
    {
        if (Physics.Raycast(controller.bounds.center, transform.rotation * Vector3.forward, out RaycastHit hit, 4.5f, 1 << gameObject.layer))
        {
            CharacterController con = hit.collider.GetComponent<CharacterController>();
            if (con != null)
            {
                PhotonView view = hit.collider.GetComponent<PhotonView>();
                photonView.RPC("Die", RpcTarget.All, photonView.Owner, view.ViewID);
            }
        }
        anim.SetBool("punchLeft", false);
        anim.SetBool("punchRight", false);
    }

    private void SetDie()
    {
        photonView.RPC("Die", RpcTarget.All, photonView.Owner, photonView.ViewID);
    }
}