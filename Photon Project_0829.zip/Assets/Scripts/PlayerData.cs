using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

using Photon.Pun;
using Photon.Realtime;

public class PlayerData : MonoBehaviourPun, IPunObservable
{
    [SerializeField] private TMP_Text txtNickName;

    [SerializeField] private SkinnedMeshRenderer mesh;
    Animator anim;
    CharacterController col;
    PhotonAnimatorView animView;
    PhotonTransformView transformView;
    AIMove aiMove;
    PlayerController controller;

    Rigidbody[] rigids;

    [SerializeField] private Material[] teamColors;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        col = GetComponent<CharacterController>();
        animView = GetComponent<PhotonAnimatorView>();
        transformView = GetComponent<PhotonTransformView>();
        aiMove = GetComponent<AIMove>();

        rigids = GetComponentsInChildren<Rigidbody>();
        UnActiveRigidbody();

        if (aiMove == null)
        {
            if (GetComponent<PhotonView>().Owner.CustomProperties["myTeam"].Equals(PhotonNetwork.LocalPlayer.CustomProperties["myTeam"]))
            {
                ShowPlayerColor();
                ShowPlayerNickName();
            }
            else
            {
                HidePlayerNickname();
            }
        }
        else
        {
            HidePlayerNickname();
        }
    }
    private void Update()
    {
        txtNickName.transform.rotation = Camera.main.transform.rotation;
    }

    public void AddController()
    {
        controller =
            gameObject.AddComponent<PlayerController>();
        gameObject.AddComponent<Spectator>().enabled = false;
    }

    public void ActiveRigidbody()
    {
        foreach (var rigid in rigids)
        {
            rigid.isKinematic = false;
            rigid.velocity = Vector3.up * 15f;
        }
    }

    public void UnActiveRigidbody()
    {
        foreach (var rigid in rigids)
        {
            rigid.isKinematic = true;
        }
    }

    //  [PunRPC]
    public void SetDie()
    {
        ActiveRigidbody();
        // ���� ���� ������ ���縦 üũ�ϰ� ��Ȱ��ȭ ��
        if (aiMove != null)
        {
            aiMove.isDead = true;
            aiMove.enabled = false;
            InGameNetworkManager.Instance.RefreshPlayerCount();
        }
        if (controller != null)
        {                  //phn          .lp         .cusp
            var properties = PhotonNetwork.LocalPlayer.CustomProperties;
            properties["isDead"] = true;
            PhotonNetwork.LocalPlayer.SetCustomProperties(properties);

            controller.enabled = false;
            GetComponent<Spectator>().enabled = true;
            ShowAllPlayerColor();
        }
        anim.enabled = false;
        col.enabled = false;
        animView.enabled = false;
        transformView.enabled = false;
        HidePlayerNickname();
    }

    [PunRPC]
    private void Die(Player killer, int victim)
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach (var player in players)
        {
            PhotonView view = player.GetComponent<PhotonView>();
            if (view.ViewID == victim)
            {
                if (player.GetComponent<AIMove>() != null)
                {
                    KillLogManager.Instance.AddLog(killer.NickName, $"�� {victim}");
                }
                else
                {
                    Player victimPlayer = player.GetComponent<PhotonView>().Owner;
                    if (killer.CustomProperties["myTeam"].Equals(victimPlayer.CustomProperties["myTeam"]))
                    {
                        ShowTeamKiller(killer);
                    }
                    KillLogManager.Instance.AddLog(killer.NickName, victimPlayer.NickName);
                    InGameNetworkManager.Instance.AddRank(victimPlayer);
                }
                player.GetComponent<PlayerData>().SetDie();
                break;
            }
        }
    }
    private void ShowTeamKiller(Player killer)
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach (var player in players)
        {
            if (player.GetComponent<AIMove>() == null)
            {
                PhotonView view = player.GetComponent<PhotonView>();
                if (view.Owner == killer)
                {
                    player.GetComponent<PlayerData>().ShowPlayerColor();
                }
            }
        }
    }

    private void ShowAllPlayerColor()
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach (var player in players)
        {
            player.GetComponent<PlayerData>().ShowPlayerColor();
            player.GetComponent<PlayerData>().ShowPlayerNickName();
        }
    }

    public void ShowPlayerColor()
    {
        if (aiMove == null)
        {
            if (photonView.Owner.CustomProperties["myTeam"].Equals("Red"))
            {
                mesh.material = teamColors[0];
            }
            else
            {
                mesh.material = teamColors[1];
            }
        }
    }

    public void ShowPlayerNickName()
    {
        if (photonView.IsMine)
        {
            HidePlayerNickname();
        }
        else
        {
            txtNickName.text = photonView.Owner.NickName;

        }
    }

    public void HidePlayerNickname()
    {
        txtNickName.text = "";
    }

        private void CreateDust()
        {
            EffectManager.Instance.CreateDust(transform.position);
        }

        public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
        {

        }
    }
