using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;

public class BotManager : MonoBehaviour
{
    private static BotManager instance;
    public static BotManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<BotManager>();
            return instance;
        }
    }

    public Vector3 RandomTarget
    {
        get
        {
            bool find = false;
            Vector3 result = Vector3.zero;
            while (!find)
            {
                Vector3 randomPosition = new Vector3(
                    Random.Range(col.bounds.min.x, col.bounds.max.x),
                    95,
                    Random.Range(col.bounds.min.z, col.bounds.max.z)
                );
                if (Physics.Raycast(randomPosition, Vector3.down, out RaycastHit hit, 95f))
                {
                    if (hit.collider.gameObject.layer != LayerMask.NameToLayer("Building"))
                    {
                        find = true;
                        result = hit.point;
                        Debug.DrawLine(hit.point, hit.point + Vector3.up * 100f, Color.yellow, 1000f);
                    }
                }
            }
            return result;
        }
    }

    public int maxCount = 30;

    private Collider col;

    private void Awake()
    {
        col = GetComponent<Collider>();
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            for (int i = 0; i < maxCount; i++)
            {
                CreateBot();
            }
        }
    }

    private void CreateBot()
    {
        bool find = false;
        while (!find)
        {
            Vector3 randomPosition = new Vector3(
                Random.Range(col.bounds.min.x, col.bounds.max.x),
                95,
                Random.Range(col.bounds.min.z, col.bounds.max.z)
            );
            if (Physics.Raycast(randomPosition, Vector3.down, out RaycastHit hit, 95f))
            {
                if (hit.collider.gameObject.layer != LayerMask.NameToLayer("Building"))
                {
                    find = true;
                    GameObject bot = Photon.Pun.PhotonNetwork.InstantiateRoomObject("Prefabs/AI Bot", hit.point, Quaternion.identity);
                    botList.Add(bot);
                }
            }
        }
    }

    private List<GameObject> botList = new List<GameObject>();
    public void ClearBot()
    {
        for (int i = 0; i < botList.Count; i++)
        {
            PhotonNetwork.Destroy(botList[i]);
        }
    }
}
