using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class AIMove : MonoBehaviour
{
    // Cache
    CharacterController controller;
    Animator anim;

    float speed = 5f;
    float jump = 12f;

    float timer = .0f;
    float delay = 3f;
    float moveTimer = .0f;
    float moveEnd = 3f;

    bool movement = false;
    Vector3 targetMoveDir;
    Vector3 moveDir;

    float gravityY = .0f;

    public bool isDead = false;
    Coroutine resetVelocity;

    Transform targetPlayer;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        anim = GetComponent<Animator>();


        if (!PhotonNetwork.LocalPlayer.IsMasterClient) return;
        isDead = false;
        anim.SetBool("isGrounded", true);

        ChangeDirection();
        Refresh();
        timer = Random.Range(0f, 15f);
        moveTimer = Random.Range(5f, 30f);
        
        if (resetVelocity == null)
        {
            //resetVelocity = StartCoroutine(InitRigidbody());
        }
    }

    void Update()
    {
        if (isDead) return;
        if (!PhotonNetwork.LocalPlayer.IsMasterClient) return;
        timer += Time.deltaTime;
        if (timer >= delay)
        {
            timer -= delay;
            ChangeDirection();
            Refresh();
        }
        moveTimer += Time.deltaTime;
        if (moveTimer >= moveEnd)
        {
            movement = false;
        }

        Vector3 moveDirIgnoreY = moveDir;
        moveDirIgnoreY.y = 0;
        transform.rotation = Quaternion.FromToRotation(Vector3.forward, moveDirIgnoreY);
        moveDir = Vector3.Lerp(moveDir, targetMoveDir, Time.deltaTime * Mathf.Clamp(Random.Range(-1f, 5f), 0f, 5f));

        anim.SetFloat("speed", 0);

        bool isGrounded = controller.isGrounded || Physics.Raycast(controller.bounds.center, Vector3.down, controller.bounds.extents.y + controller.skinWidth + .8f);
        if (movement)
        {
            if (controller.isGrounded)
            {
                gravityY = .0f;
            }
            anim.SetFloat("speed", moveDirIgnoreY.normalized.magnitude);
        }
        gravityY += Physics.gravity.y * Time.deltaTime;
        if (movement) 
        {
            moveDir.y = gravityY;
            controller.Move(moveDir * Time.deltaTime);

            int changeLayer = (1 << LayerMask.NameToLayer("Building")) + (1 << LayerMask.NameToLayer("changeDirection"));

            if (Physics.Raycast(controller.bounds.center, targetMoveDir.normalized, 2f, changeLayer))
            {
                ChangeDirection();
            }
        }
        Debug.DrawLine(controller.bounds.center, controller.bounds.center + moveDirIgnoreY * 12, Color.red);
        if (isGrounded && Random.Range(0f, 1f) < .0003f)
        {
            SetJump();
        }
        anim.SetBool("moveForward", movement);
        anim.SetBool("isGrounded", isGrounded);
    }



    private void ChangeDirection()
    {
        targetMoveDir = BotManager.Instance.RandomTarget - transform.position;
        targetMoveDir.y = 0;
        targetMoveDir.Normalize();
        targetMoveDir *= speed;
    }

    private void Refresh()
    {
        if (moveTimer >= moveEnd)
        {
            movement = true;
            moveTimer = .0f;
        }
        delay = Random.Range(0f, 15f);
        moveEnd = Random.Range(5f, 30f);
    }

    private void SetJump()
    {
        gravityY = jump;
    }
}
