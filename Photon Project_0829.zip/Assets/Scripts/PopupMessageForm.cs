using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PopupMessageForm : MonoBehaviour
{
    private static PopupMessageForm instance;
    public static PopupMessageForm Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<PopupMessageForm>();
            return instance;
        }
    }

    [SerializeField] private GameObject areaForm;
    [SerializeField] private Text txtContent;
    [SerializeField] private Button btnSubmit;

    private void Awake()
    {
        areaForm.SetActive(false);
        btnSubmit.onClick.AddListener(Submit);
    }

    private void Submit()
    {
        areaForm.SetActive(false);
    }

    public void SetMessage(string content)
    {
        areaForm.SetActive(true);
        txtContent.text = content;
    }
}
