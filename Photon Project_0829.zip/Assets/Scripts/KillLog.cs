using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Pun;
using Photon.Realtime;

public class KillLog : MonoBehaviour
{
    [SerializeField] private Text txtKiller;
    [SerializeField] private Text txtVictim;

    public void SetLog(string killer, string victim)
    {
        txtKiller.text = killer;
        txtVictim.text = victim;
    }

    private void RemoveLog()
    {
        Destroy(gameObject);
    }
}
