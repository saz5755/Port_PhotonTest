using Photon.Pun;
using Photon.Realtime;

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    private static UIManager instance;

    public static UIManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<UIManager>();
            return instance;
        } 
    }

    private Dictionary<string, RoomInfo> roomList = new Dictionary<string, RoomInfo>();

    [Header("*** ū ����")]
    [SerializeField] private GameObject areaConnectingUI;
    [SerializeField] private GameObject areaNicknameSettingUI;
    [SerializeField] private GameObject areaRoomListUI;
    [SerializeField] private GameObject areaCreateRoomUI;
    [SerializeField] private GameObject areaRoomUI;

    [Header("*** �г��� �Է� ���� UI")]
    [Space(20)]
    [SerializeField] private InputField inputNickname;
    [SerializeField] private Button btnNicknameSubmit;

    [Header("*** �� ��� ���� UI")]
    [Space(20)]
    [SerializeField] private Button btnOpenCreateRoom;
    [SerializeField] private Transform roomListParent;
    private GameObject roomListPrefab;
    private List<RoomListItem> roomListObjects = new List<RoomListItem>();

    [Header("*** �� ���� ���� UI")]
    [Space(20)]
    [SerializeField] private InputField inputRoomName;
    [SerializeField] private Slider sliderMaxPlayerCount;
    [SerializeField] private Button btnCreate;
    [SerializeField] private Button btnCreateCancel;

    [Header("*** �� ���� UI")]
    [Space(20)]
    [SerializeField] private Button btnLeftRoom;
    [SerializeField] private Transform redPlayerListParent;
    [SerializeField] private Transform bluePlayerListParent;
    private GameObject playerListPrefab;
    private List<PlayerListItem> redPlayerListObjects = new List<PlayerListItem>();
    private List<PlayerListItem> bluePlayerListObjects = new List<PlayerListItem>();

    [SerializeField] private Button btnSwitchRedTeam;
    [SerializeField] private Button btnSwitchBlueTeam;

    [SerializeField] private Button btnSetReady;
    [SerializeField] private Button btnCancelReady;
    [SerializeField] private Button btnGameStart;

    private void Awake()
    {
        roomListPrefab = Resources.Load<GameObject>("Prefabs/RoomListItem");
        InitNicknameUI();
        InitRoomListUI();
        InitCreateRoomUI();
        InitRoomUI();
        InitializeSetting();
    }

    public void ConnectedToServer()
    {
        areaConnectingUI.SetActive(false);
        areaNicknameSettingUI.SetActive(true);
    }

    private void InitializeSetting()
    {
        if (PhotonNetwork.InRoom)
        {
            NetworkManager.Instance.RefreshAllPlayer();
            JoinRoom(PhotonNetwork.CurrentRoom);
        }
        else
        {
            Debug.Log("A");
            areaConnectingUI.SetActive(true);
            areaNicknameSettingUI.SetActive(false);
            areaRoomListUI.SetActive(false);
            areaCreateRoomUI.SetActive(false);
            areaRoomUI.SetActive(false);
        }
    }

    private void InitNicknameUI()
    {
        inputNickname.text = PlayerPrefs.GetString("Nickname");
        btnNicknameSubmit.onClick.AddListener(SetNickname); // Ŭ�������� � �̺�Ʈ�� ����� ������?
    }

    private void InitRoomListUI()
    {
        btnOpenCreateRoom.onClick.AddListener(OpenCreateRoomUI); // �� ����� UI ����
    }

    private void InitCreateRoomUI()
    {
        btnCreate.onClick.AddListener(CreateRoom); // �� �����ϱ�, �� ��� �����, �� �ȿ� �� UI �ѱ�
        btnCreateCancel.onClick.AddListener(CreateCancel);
    }

    private void InitRoomUI()
    {
        playerListPrefab = Resources.Load<GameObject>("Prefabs/PlayerListItem");
        for (int i = 0; i < 10; i++)
        {
            PlayerListItem item = Instantiate(playerListPrefab, redPlayerListParent).GetComponent<PlayerListItem>();
            redPlayerListObjects.Add(item);
        }
        for (int i = 0; i < 10; i++)
        {
            PlayerListItem item = Instantiate(playerListPrefab, bluePlayerListParent).GetComponent<PlayerListItem>();
            bluePlayerListObjects.Add(item);
        }
        btnLeftRoom.onClick.AddListener(LeftRoom);

        btnSwitchRedTeam.onClick.AddListener(() => ChangeTeam("Red"));
        btnSwitchBlueTeam.onClick.AddListener(() => ChangeTeam("Blue"));

        btnSetReady.onClick.AddListener(SetReady);
        btnCancelReady.onClick.AddListener(CancelReady);
        btnGameStart.onClick.AddListener(GameStart);
    }

    private void SetNickname() // �г��� ���� / Network �гۿ� ���ٿ��� ����
    {
        NetworkManager.Instance.SetNickname(inputNickname.text); // �̱��濡 ���� text�� ����
        areaNicknameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(true);
        PlayerPrefs.SetString("Nickname", inputNickname.text);
    }

    public void RoomListUIRefresh(Dictionary<string, RoomInfo> roomList)
    {
        for (int i = 0; i < roomListObjects.Count; i++)
        {
            Destroy(roomListObjects[i].gameObject);
        }
        roomListObjects.Clear();
       
        foreach (var room in roomList)
        {
            RoomListItem listItem = Instantiate(roomListPrefab, roomListParent).GetComponent<RoomListItem>();
            listItem.SetListItem(room.Value);
            roomListObjects.Add(listItem);
        }
    }

    private void OpenCreateRoomUI()
    {
        areaCreateRoomUI.SetActive(true);
    }

    private void CreateRoom()
    {
        if (inputRoomName.text == "")
        {
            Debug.Log("�� �̸��� ����ֽ��ϴ�!");
        }
        else
        {
            if (NetworkManager.Instance.AlreadyExistRoomName(inputRoomName.text))
            {
                Debug.Log("�̹� �� ������ ���� ����");
            }
            else
            {
                NetworkManager.Instance.CreateRoom(inputRoomName.text, (byte)sliderMaxPlayerCount.value);
            }
        }
    }

    private void CreateCancel()
    {
        areaCreateRoomUI.SetActive(false);
    }

    public void LeftRoom()
    {
        NetworkManager.Instance.LeftRoom();
        areaRoomListUI.SetActive(true);
        areaRoomUI.SetActive(false);
    }

    public void JoinRoom(RoomInfo info)
    {
        areaConnectingUI.SetActive(false);
        areaNicknameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(false);
        areaCreateRoomUI.SetActive(false);
        areaRoomUI.SetActive(true);
    }

    private void ChangeTeam(string team)
    {
        NetworkManager.Instance.SetProperties("myTeam", team);
    }

    private void SetReady()
    {
        NetworkManager.Instance.SetProperties("isReady", true);
        btnSetReady.gameObject.SetActive(false);
        btnCancelReady.gameObject.SetActive(true);
    }

    private void CancelReady()
    {
        NetworkManager.Instance.SetProperties("isReady", false);
        btnSetReady.gameObject.SetActive(true);
        btnCancelReady.gameObject.SetActive(false);
    }

    private void GameStart()
    {
        NetworkManager.Instance.GameStart();
    }

    public void PlayerListUIRefresh(Dictionary<string, Player> playerList)
    {
        List<Player> redPlayers = new List<Player>();
        List<Player> bluePlayers = new List<Player>();

        for (int i = 0; i < redPlayerListObjects.Count; i++)
        {
            redPlayerListObjects[i].Clear();
        }
        for (int i = 0; i < bluePlayerListObjects.Count; i++)
        {
            bluePlayerListObjects[i].Clear();
        }

        foreach (var player in playerList.Values)
        {
            if (player.CustomProperties["myTeam"].Equals("Red"))
            {
                redPlayers.Add(player);
            }
            else
            {
                bluePlayers.Add(player);
            }
        }

        for (int i = 0; i < redPlayers.Count; i++)
        {
            redPlayerListObjects[i].Refresh(redPlayers[i]);
        }
        for (int i = 0; i < bluePlayers.Count; i++)
        {
            bluePlayerListObjects[i].Refresh(bluePlayers[i]);
        }
        CheckMasterClient();
    }

    public void CheckMasterClient()
    {
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            btnSetReady.gameObject.SetActive(false);
            btnCancelReady.gameObject.SetActive(false);
            btnGameStart.gameObject.SetActive(true);
        }
        else
        {
            bool isReady = (bool)PhotonNetwork.LocalPlayer.CustomProperties["isReady"];

            btnSetReady.gameObject.SetActive(!isReady);
            btnCancelReady.gameObject.SetActive(isReady);
            btnGameStart.gameObject.SetActive(false);
        }
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F4))
        {
            Debug.Log(Photon.Pun.PhotonNetwork.InRoom);
            Debug.Log(Photon.Pun.PhotonNetwork.InLobby);
        }
    }
}
