using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum WinnerTeam
{
    Red = 0, Blue, Draw
}

public class InGameUIManager : MonoBehaviour
{
    private static InGameUIManager instance;
    public static InGameUIManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<InGameUIManager>();
            return instance;
        }
    }

    [SerializeField] private Text txtRedCount;
    [SerializeField] private Text txtBlueCount;
    [SerializeField] private Text txtTotalCount;

    [SerializeField] private GameObject areaGameOver;
    [SerializeField] private Text txtWinnerTeam;
    [SerializeField] private Button btnReturnMainScene;

    [SerializeField] private Image imgStaminaGauge;

    private void Awake()
    {
        btnReturnMainScene.onClick.AddListener(ReturnToMain);
        areaGameOver.SetActive(false);
    }

    private void ReturnToMain()
    {
        InGameNetworkManager.Instance.ClearMyProperties();
        InGameNetworkManager.Instance.ReturnToMain();
    }

    public void SetPlayersCount(int red, int blue, int total)
    {
        // #,##0 => 12,315,325
        txtRedCount.text = $"{red:#,##0}";
        txtBlueCount.text = $"{blue:#,##0}";
        txtTotalCount.text = $"{total:#,##0}";
    }

    public void ShowGameOverUI(WinnerTeam winner)
    {
        Cursor.lockState = CursorLockMode.None;
        switch (winner)
        {
            case WinnerTeam.Red:
                txtWinnerTeam.text = "������ �¸�";
                break;
            case WinnerTeam.Blue:
                txtWinnerTeam.text = "�Ķ��� �¸�";
                break;
            case WinnerTeam.Draw:
                txtWinnerTeam.text = "���º�";
                break;
            default:
                break;
        }
        areaGameOver.SetActive(true);
    }

    public void RefreshStaminaGauge(float value)
    {
        imgStaminaGauge.fillAmount = value;
    }
}
