using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Animator anim;

    private float speed = 5f;
    private float jump = 12f;
    private float distance = 10f;
    private Vector3 offset = new Vector3(1.2f, 3f, 0);

    private CharacterController controller;
    private float angleX, angleY, gravityY;
    private Vector3 moveDir;
    private float horizontal, vertical;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        angleX -= Input.GetAxis("Mouse Y");
        angleY += Input.GetAxis("Mouse X");
        Camera.main.transform.rotation = Quaternion.Euler(angleX, angleY, 0);
        Camera.main.transform.position = transform.position + Quaternion.Euler(angleX, angleY, 0) * -Vector3.forward * distance + Quaternion.Euler(angleX, angleY, 0) * offset;
        transform.rotation = Quaternion.Euler(0, angleY, 0);

        horizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");

        if (controller.isGrounded || Physics.Raycast(controller.bounds.center, Vector3.down, controller.bounds.extents.y + controller.skinWidth + .02f))
        {
            gravityY = .0f;

            if (Input.GetKey(KeyCode.Space)) gravityY = jump;

            moveDir = Quaternion.Euler(0, angleY, 0) * new Vector3(horizontal, 0, vertical);
            if (moveDir.magnitude > 1) moveDir.Normalize();

            moveDir *= speed;
            anim.SetBool("isGrounded", true);
        }
        else
        {
            anim.SetBool("isGrounded", false);
        }
        anim.SetBool("moveForward", vertical > 0);
        anim.SetBool("moveBackward", vertical < 0);

        gravityY += Physics.gravity.y * Time.deltaTime;
        moveDir.y = gravityY;

        controller.Move(moveDir * Time.deltaTime);
        Punch();
    }

    private void Punch()
    {
        bool punchable = !(anim.GetBool("punchLeft") || anim.GetBool("punchRight"));
        if (punchable)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (Random.Range(0f, 1f) < .5f)
                {
                    anim.SetBool("punchLeft", true);
                }
                else
                {
                    anim.SetBool("punchRight", true);
                }
            }
        }
    }

    private void SetPunch()
    {
        anim.SetBool("punchLeft", false);
        anim.SetBool("punchRight", false);
    }
}