using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;

public class InGameNetworkManager : MonoBehaviour
{
    private void Awake()
    {
        Vector3 position = new Vector3(Random.Range(-5f, 5f), 0, Random.Range(-5f, 5f));
        GameObject myCharacter = PhotonNetwork.Instantiate("Prefabs/Player", position, Quaternion.identity);
        myCharacter.AddComponent<CharacterController>();
        myCharacter.AddComponent<PlayerController>();

        myCharacter.GetComponent<CharacterController>().height = 3.8f;
        myCharacter.GetComponent<CharacterController>().center = new Vector3(0, 1.9f, 0);
    }
}
