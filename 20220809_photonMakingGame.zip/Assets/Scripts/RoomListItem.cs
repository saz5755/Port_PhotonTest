using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;


public class RoomListItem : MonoBehaviour
{
    [SerializeField] private Text txtTitle;
    [SerializeField] private Text txtPlayers;

    public void SetListItem(RoomInfo info)
    {
        txtTitle.text = info.Name;
        txtPlayers.text = $"{info.PlayerCount} / {info.MaxPlayers}";

        GetComponent<Button>().onClick.RemoveAllListeners();
        GetComponent<Button>().onClick.AddListener(() =>
        {
            PhotonNetwork.JoinRoom(info.Name);

        });
    }

}
