using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerListItem : MonoBehaviour
{
    [SerializeField] private GameObject isReadyObject;
    [SerializeField] private Text txtNickname;

    public void Clear()
    {
        txtNickname.text = "";
        isReadyObject.SetActive(false);
        GetComponent<Image>().color = Color.white;
    }

    public void Refresh(Player player)
    {
        txtNickname.text = player.NickName;

        bool isReady = (bool)player.CustomProperties["isReady"];
        
        isReadyObject.SetActive(isReady);

        if (player.IsMasterClient)
        {
            GetComponent<Image>().color = new Color(.9f, .4f, .5f);
        }
        else
        {
            GetComponent<Image>().color = Color.white;
        }
    }
}
