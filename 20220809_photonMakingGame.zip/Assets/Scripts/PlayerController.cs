using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float speed = 5f;
    private float jump = 12f;
    private float distance = 10f;
    private Vector3 offset = new Vector3(1.2f, 3f, 0);

    private CharacterController controller;
    private float angleX, angleY, gravityY;
    private Vector3 moveDir;
    private float horizontal, veritcal;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        angleX -= Input.GetAxis("Mouse Y");
        angleY += Input.GetAxis("Mouse X");
        Camera.main.transform.rotation = Quaternion.Euler(angleX, angleY, 0);
        Camera.main.transform.position = transform.position + Quaternion.Euler(angleX, angleY, 0) * -Vector3.forward * distance + Quaternion.Euler(angleX, angleY, 0) * offset;
        transform.rotation = Quaternion.Euler(0, angleY, 0);

        if (controller.isGrounded || Physics.Raycast(controller.bounds.center, Vector3.down, controller.bounds.extents.y + controller.skinWidth + .02f))
        {
            horizontal = Input.GetAxis("Horizontal");
            veritcal = Input.GetAxis("Vertical");
            gravityY = .0f;

            if (Input.GetKey(KeyCode.Space)) gravityY = jump;

            moveDir = Quaternion.Euler(0, angleY, 0) * new Vector3(horizontal, 0, veritcal);
            if (moveDir.magnitude > 1) moveDir.Normalize();

            moveDir *= speed;
        }

        gravityY += Physics.gravity.y * Time.deltaTime;
        moveDir.y = gravityY;

        controller.Move(moveDir * Time.deltaTime);
    }
}