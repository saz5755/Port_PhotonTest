using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;

public class NetworkManager : MonoBehaviour
{
    private static NetworkManager instance;
    public static NetworkManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<NetworkManager>();
            }
            return instance;
        }
    }

    private Dictionary<string, RoomInfo> roomList = new Dictionary<string, RoomInfo>();

    private void Awake()
    {
        PhotonNetwork.ConnectUsingSettings();
    }

    public void SetNickName(string nickname)
    {
        PhotonNetwork.NickName = nickname;
        PhotonNetwork.JoinLobby();
    }

    public void RoomListUpdate(List<RoomInfo> data)
    {
        for (int i = 0; i < data.Count; i++)
        {
            Debug.Log(data[i].Name);
        }
    }
}
