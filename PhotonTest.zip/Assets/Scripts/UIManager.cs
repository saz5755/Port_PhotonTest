using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    private static UIManager instance;
    public static UIManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<UIManager>();
            }
            return instance;
        }
    }

    [SerializeField] private GameObject areaConnectingUI;
    [SerializeField] private GameObject areaNickNameSettingUI;
    [SerializeField] private GameObject areaRoomListUI;

    [SerializeField] private InputField inputNickName;
    [SerializeField] Button btnNickNameSubmit;

    private void Awake()
    {
        InitializeSetting();
        InitNickNameUI();
    }

    public void ConnnectedToServer()
    {
        areaConnectingUI.SetActive(false);
        areaNickNameSettingUI.SetActive(true);
    }

    private void InitializeSetting()
    {
        areaConnectingUI.SetActive(true);
        areaNickNameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(false);
    }

    private void InitNickNameUI()
    {
        btnNickNameSubmit.onClick.AddListener(SetNickName);
    }


    private void SetNickName()
    {
        NetworkManager.Instance.SetNickName(inputNickName.text);
        areaNickNameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(true);

    }




}
