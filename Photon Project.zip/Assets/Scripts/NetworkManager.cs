using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;


public class NetworkManager : MonoBehaviourPun
{
    private static NetworkManager instance;

    public static NetworkManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<NetworkManager>();
            return instance;
        }
    }

    private Dictionary<string, RoomInfo> roomList = new Dictionary<string, RoomInfo>();

    private Dictionary<string, Player> playerList = new Dictionary<string, Player>();

    private void Awake()
    {
        PhotonNetwork.ConnectUsingSettings(); // ������ �ߴ��� ���ߴ��� Ȯ�� ����.
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F3))
        {
            foreach (var room in roomList)
            {
                Debug.Log(room.Value.CustomProperties);
            }
        }
    }

    public void SetNickname(string nickname) // photon ��Ʈ��ũ�� �� �г� �����ϱ�
    {
        PhotonNetwork.NickName = nickname;
        PhotonNetwork.JoinLobby();
    }

    public void RoomListUpdate(List<RoomInfo> data)
    {
        for (int i = 0; i < data.Count; i++)
        {
            if (data[i].RemovedFromList || data[i].IsOpen == false)
            {
                roomList.Remove(data[i].Name); // ������ ���ؼ� key���� ��� ���ܽ����ش�.
            }
            else
            {
                if (roomList.ContainsKey(data[i].Name)) // �������̶�� Key���� �����ϴ��� Ȯ���ϱ�
                {
                    roomList[data[i].Name] = data[i];
                }
                else
                {
                    roomList.Add(data[i].Name,data[i]);
                    
                }
            }
            
        }
        UIManager.Instance.RoomListUIRefresh(roomList);
    }

    // 
    public bool AlreadyExistRoomName(string roomName)
    {
        return roomList.ContainsKey(roomName);
    }

    public void CreateRoom(string roomName, byte maxPlayerCount)
    {
        RoomOptions option = new RoomOptions();
        option.CustomRoomProperties = new ExitGames.Client.Photon.Hashtable()
        {
            { "isStart", false },
            { "dummyCount", 30 }
        };
        option.IsOpen = true;
        option.MaxPlayers = maxPlayerCount;
        PhotonNetwork.CreateRoom(roomName, option);
    }

    public void ClearRoom()
    {
        roomList.Clear();
    }

    public void LeftRoom()
    {
        PhotonNetwork.LeaveRoom();
    }

    public void ClearPlayerList()
    {
        playerList.Clear();
    }

    public void RefreshAllPlayer()
    {
        ClearPlayerList();
        foreach (var player in PhotonNetwork.CurrentRoom.Players.Values)
        {
            playerList.Add(player.NickName, player);
        }
        UIManager.Instance.PlayerListUIRefresh(playerList);
    }

    public void AddPlayer(Player player)
    {
        if (!playerList.ContainsKey(player.NickName))
        {
            playerList.Add(player.NickName, player);
        }
        UIManager.Instance.PlayerListUIRefresh(playerList);
    }

    public void RemovePlayer(Player player)
    {
        if (playerList.ContainsKey(player.NickName))
        {
            playerList.Remove(player.NickName);
        }
        UIManager.Instance.PlayerListUIRefresh(playerList);
    }

    public void RefreshPlayer(Player player)
    {
        if (playerList.ContainsKey(player.NickName))
        {
            playerList[player.NickName] = player;
        }
        else
        {
            AddPlayer(player);
        }
        UIManager.Instance.PlayerListUIRefresh(playerList);
    }

    public void SetProperties(object key, object value)
    {
        var properties = PhotonNetwork.LocalPlayer.CustomProperties;
        properties[key] = value;
        PhotonNetwork.LocalPlayer.SetCustomProperties(properties);
    }

    public void SetRoomProperties(object key, object value)
    {
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            var properties = PhotonNetwork.CurrentRoom.CustomProperties;
            properties[key] = value;
            PhotonNetwork.CurrentRoom.SetCustomProperties(properties);
        }
    }

    public void GameStart()
    {
        bool allReady = true;
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            foreach (var player in playerList.Values)
            {
                if (player.CustomProperties["isReady"].Equals(false))
                {
                    if (!player.IsMasterClient)
                    {
                        allReady = false;
                        break;
                    }
                }
            }
            // �Ѹ��̶� ���� �Ǿ����� ������ allReady�� ���� false�� ��
            if (allReady == true)
            {
                PhotonNetwork.CurrentRoom.IsOpen = false;
                SetRoomProperties("isStart", true);
            }
            else
            {
                Debug.Log("���� ���� ���� ������");
            }
        }
    }

    public void Kick(Player player)
    {
        photonView.RPC("KickPlayer", player);
    }

    [PunRPC]
    private void KickPlayer()
    {
        UIManager.Instance.LeftRoom();
        PopupMessageForm.Instance.SetMessage("�� ������� ����");
    }
}
