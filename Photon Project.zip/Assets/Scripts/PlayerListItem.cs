using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

using Photon.Pun;

public class PlayerListItem : MonoBehaviour, IPointerClickHandler
{
    Player player;
    [SerializeField] private GameObject isReadyObject;
    [SerializeField] private Text txtNickname;

    public void Clear()
    {
        txtNickname.text = "";
        isReadyObject.SetActive(false);
        GetComponent<Image>().color = Color.white;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            if (eventData.button == PointerEventData.InputButton.Right)
            {
                NetworkManager.Instance.Kick(player);
            }
        }
    }

    public void Refresh(Player player)
    {
        this.player = player;
        txtNickname.text = player.NickName;

        bool isReady = (bool)player.CustomProperties["isReady"];
        
        isReadyObject.SetActive(isReady);

        if (player.IsMasterClient)
        {
            GetComponent<Image>().color = new Color(.9f, .4f, .5f);
        }
        else
        {
            GetComponent<Image>().color = Color.white;
        }
    }
}
