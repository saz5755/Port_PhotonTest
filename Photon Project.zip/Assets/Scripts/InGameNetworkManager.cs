using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;

public class InGameNetworkManager : MonoBehaviourPunCallbacks
{
    private static InGameNetworkManager instance;
    public static InGameNetworkManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<InGameNetworkManager>();
            return instance;
        }
    }

    private int redCount;
    private int blueCount;
    private int totalCount;

    private Dictionary<string, Player> rankNickname = new Dictionary<string, Player>();

    private GameObject myCharacter;

    private void Awake()
    {
        Vector3 position = BotManager.Instance.RandomTarget + Vector3.up * .05f;//new Vector3(Random.Range(-5f, 5f), 0, Random.Range(-5f, 5f));
        myCharacter = PhotonNetwork.Instantiate("Prefabs/Player", position, Quaternion.identity);

        myCharacter.GetComponent<PlayerData>().AddController();

        Cursor.lockState = CursorLockMode.Locked;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F3))
        {
            string rank = "";
            foreach (var player in rankNickname)
            {
                rank += $"{player.Value.NickName}\n";
            }
            Debug.Log(rank);
            foreach (var item in PhotonNetwork.CurrentRoom.Players.Values)
            {
                Debug.Log(item.CustomProperties);
            }
        }
    }

    public void ClearMyProperties()
    {
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            PhotonNetwork.CurrentRoom.IsOpen = true;
            BotManager.Instance.ClearBot();
        }
        PhotonNetwork.Destroy(myCharacter);
        var properties = PhotonNetwork.LocalPlayer.CustomProperties;
        properties["isDead"] = false;
        properties["isReady"] = false;
        PhotonNetwork.LocalPlayer.SetCustomProperties(properties);
    }

    public void AddRank(Player player)
    {
        if (!rankNickname.ContainsKey(player.NickName))
        {
            rankNickname.Add(player.NickName, player);
        }
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        RefreshPlayerCount();
    }

    public override void OnPlayerPropertiesUpdate(Player targetPlayer, ExitGames.Client.Photon.Hashtable changedProps)
    {
        RefreshPlayerCount();
    }

    public void RefreshPlayerCount()
    {
        int redCount = 0;
        int blueCount = 0;
        int totalCount = 0;

        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach (var player in players)
        {
            if (player.GetComponent<AIMove>() != null)
            {
                if (!player.GetComponent<AIMove>().isDead)
                {
                    totalCount++;
                }
            }
            else
            {
                if (player.GetComponent<PhotonView>().Owner.CustomProperties["isDead"].Equals(false))
                {
                    if (player.GetComponent<PhotonView>().Owner.CustomProperties["myTeam"].Equals("Red"))
                    {
                        redCount++;
                        totalCount++;
                    }
                    else
                    {
                        blueCount++;
                        totalCount++;
                    }
                }
            }
        }

        if (this.redCount != redCount)
        {
            // RedCount �ؽ�Ʈ�� ���~ �ϰ� �ִϸ��̼� �����ض�
        }

        this.redCount = redCount;
        this.blueCount = blueCount;
        this.totalCount = totalCount;

        InGameUIManager.Instance.SetPlayersCount(redCount, blueCount, totalCount);
        CheckGameOver();
    }

    private void CheckGameOver()
    {
        if (redCount <= 0 && blueCount <= 0)
        {
            InGameUIManager.Instance.ShowGameOverUI(WinnerTeam.Draw);
        }
        else if (redCount <= 0)
        {
            InGameUIManager.Instance.ShowGameOverUI(WinnerTeam.Blue);
        }
        else if (blueCount <= 0)
        {
            InGameUIManager.Instance.ShowGameOverUI(WinnerTeam.Red);
        }
    }

    public void ReturnToMain()
    {
        SceneController.Instance.LoadScene("MainScene");
    }
}
