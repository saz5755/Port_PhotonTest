using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;

public class PlayerData : MonoBehaviourPun, IPunObservable
{
    [SerializeField] private SkinnedMeshRenderer mesh;
    Animator anim;
    CharacterController col;
    PhotonAnimatorView animView;
    PhotonTransformView transformView;
    AIMove aiMove;
    PlayerController controller;

    [SerializeField] private Material[] teamColors;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        col = GetComponent<CharacterController>();
        animView = GetComponent<PhotonAnimatorView>();
        transformView = GetComponent<PhotonTransformView>();
        aiMove = GetComponent<AIMove>();

        if (aiMove == null)
        {
            if (GetComponent<PhotonView>().Owner.CustomProperties["myTeam"].Equals(PhotonNetwork.LocalPlayer.CustomProperties["myTeam"]))
            {
                if (PhotonNetwork.LocalPlayer.CustomProperties["myTeam"].Equals("Red"))
                {
                    mesh.material = teamColors[0];
                }
                else
                {
                    mesh.material = teamColors[1];
                }
            }
        }
    }

    public void AddController()
    {
        controller = 
            gameObject.AddComponent<PlayerController>();
            gameObject.AddComponent<Spectator>().enabled = false;
    }

//  [PunRPC]
    public void SetDie()
    {
        // ���� ���� ������ ���縦 üũ�ϰ� ��Ȱ��ȭ ��
        if (aiMove != null)
        {
            aiMove.isDead = true;
            aiMove.ActiveRigidbody();
            aiMove.enabled = false;
            InGameNetworkManager.Instance.RefreshPlayerCount();
        }
        if (controller != null)
        {                  //phn          .lp         .cusp
            var properties = PhotonNetwork.LocalPlayer.CustomProperties;
            properties["isDead"] = true;
            PhotonNetwork.LocalPlayer.SetCustomProperties(properties);

            controller.enabled = false;
            GetComponent<Spectator>().enabled = true;
        }
        anim.enabled = false;
        col.enabled = false;
        animView.enabled = false;
        transformView.enabled = false;
    }

    [PunRPC]
    private void Die(Player killer, int victim)
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        foreach (var player in players)
        {
            PhotonView view = player.GetComponent<PhotonView>();
            if (view.ViewID == victim)
            {
                if (player.GetComponent<AIMove>() != null)
                {
                    KillLogManager.Instance.AddLog(killer.NickName, $"�� {victim}");
                }
                else
                {
                    KillLogManager.Instance.AddLog(killer.NickName, player.GetComponent<PhotonView>().Owner.NickName);
                    InGameNetworkManager.Instance.AddRank(player.GetComponent<PhotonView>().Owner);
                }
                player.GetComponent<PlayerData>().SetDie();
                break;
            }
        }
    }

    public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {
        
    }
}
