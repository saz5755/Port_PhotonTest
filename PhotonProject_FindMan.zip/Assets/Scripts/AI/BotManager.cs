using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;

public class BotManager : MonoBehaviour
{
    private static BotManager instance;
    public static BotManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<BotManager>();
            return instance;
        }
    }

    public Vector3 RandomTarget
    {
        get
        {
            bool find = false;
            Vector3 result = Vector3.zero;
            while (!find)
            {
                Vector3 randomPosition = new Vector3(
                    Random.Range(-col.bounds.extents.x, col.bounds.extents.x),
                    45,
                    Random.Range(-col.bounds.extents.z, col.bounds.extents.z)
                );
                if (Physics.Raycast(randomPosition, Vector3.down, out RaycastHit hit, 45f))
                {
                    if (hit.collider.gameObject.layer != LayerMask.NameToLayer("Building"))
                    {
                        find = true;
                        result = randomPosition;
                    }
                }
            }
            return result;
        }
    }

    public int maxCount = 30;

    private Collider col;

    private void Awake()
    {
        col = GetComponent<Collider>();
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            for (int i = 0; i < maxCount; i++)
            {
                CreateBot();
            }
        }
    }

    private void CreateBot()
    {
        bool find = false;
        while (!find)
        {
            Vector3 randomPosition = new Vector3(
                Random.Range(-col.bounds.extents.x, col.bounds.extents.x),
                45,
                Random.Range(-col.bounds.extents.z, col.bounds.extents.z)
            );
            if (Physics.Raycast(randomPosition, Vector3.down, out RaycastHit hit, 45f))
            {
                if (hit.collider.gameObject.layer != LayerMask.NameToLayer("Building"))
                {
                    find = true;
                    GameObject bot = Photon.Pun.PhotonNetwork.InstantiateRoomObject("Prefabs/AI Bot", hit.point, Quaternion.identity);
                    botList.Add(bot);
                }
            }
        }
    }

    private List<GameObject> botList = new List<GameObject>();
    public void ClearBot()
    {
        for (int i = 0; i < botList.Count; i++)
        {
            PhotonNetwork.Destroy(botList[i]);
        }
    }
}
