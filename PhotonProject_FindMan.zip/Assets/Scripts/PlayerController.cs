using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;

public class PlayerController : MonoBehaviourPun
{
    Animator anim;

    private float speed = 5f;
    private float jump = 12f;
    private float distance = 10f;

    private CharacterController controller;
    private float angleX, angleY, gravityY;
    private Vector3 moveDir;
    private float horizontal, vertical;

    int ignoreLayer;

    private void Awake()
    {
        ignoreLayer = ~((1 << gameObject.layer) | (1 << LayerMask.NameToLayer("Player")));
        anim = GetComponent<Animator>();
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        angleX -= Input.GetAxis("Mouse Y");
        angleY += Input.GetAxis("Mouse X");
        Camera.main.transform.rotation = Quaternion.Euler(angleX, angleY, 0);

        Vector3 pivot = controller.bounds.center + Vector3.up * 1.2f;
        Vector3 direction = Quaternion.Euler(angleX, angleY, 0) * -Vector3.forward;
        float dis = distance;

        if (Physics.Raycast(pivot, direction, out RaycastHit hit, distance, ignoreLayer))
        {
            dis = hit.distance * .98f;
        }

        Camera.main.transform.position = pivot + Quaternion.Euler(angleX, angleY, 0) * -Vector3.forward * dis;

        transform.rotation = Quaternion.Euler(0, angleY, 0);

        horizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");

        if (controller.isGrounded || Physics.Raycast(controller.bounds.center, Vector3.down, controller.bounds.extents.y + controller.skinWidth + .02f, ignoreLayer))
        {
            gravityY = .0f;

            if (Input.GetKey(KeyCode.Space)) gravityY = jump;

            moveDir = Quaternion.Euler(0, angleY, 0) * new Vector3(horizontal, 0, vertical);
            if (moveDir.magnitude > 1) moveDir.Normalize();

            moveDir *= speed;
            anim.SetBool("isGrounded", true);
        }
        else
        {
            anim.SetBool("isGrounded", false);
        }
        anim.SetBool("moveForward", vertical > 0);
        anim.SetBool("moveBackward", vertical < 0);

        gravityY += Physics.gravity.y * Time.deltaTime;
        moveDir.y = gravityY;

        controller.Move(moveDir * Time.deltaTime);
        Punch();
        if (Input.GetKeyDown(KeyCode.F5))
        {
            SetDie();
        }
    }

    private void Punch()
    {
        bool punchable = !(anim.GetBool("punchLeft") || anim.GetBool("punchRight"));
        if (punchable)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (Random.Range(0f, 1f) < .5f)
                {
                    anim.SetBool("punchLeft", true);
                }
                else
                {
                    anim.SetBool("punchRight", true);
                }
            }
        }
    }

    private void SetPunch()
    {
        if (Physics.Raycast(controller.bounds.center, transform.rotation * Vector3.forward, out RaycastHit hit, 4.5f, 1 << gameObject.layer))
        {
            CharacterController con = hit.collider.GetComponent<CharacterController>();
            if (con != null)
            {
                PhotonView view = hit.collider.GetComponent<PhotonView>();
                photonView.RPC("Die", RpcTarget.All, photonView.Owner, view.ViewID);
            }
        }
        anim.SetBool("punchLeft", false);
        anim.SetBool("punchRight", false);
    }

    private void SetDie()
    {
        anim.enabled = false;
        controller.enabled = false;
        this.enabled = false;
    }
}