using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spectator : MonoBehaviour
{
    private Transform targetPlayer;
    private float distance = 10f;
    private float angleX, angleY;
    private Vector3 offset = Vector3.up * 3.5f;
    private bool isFlying = false;

    private void Awake()
    {
        targetPlayer = transform;
    }

    private void Update()
    {
        if (isFlying)
        {
            FlyingView();
        }
        else
        {
            if (targetPlayer != null)
            {
                SpectateView();
            }
            FindTargetPlayer();
        }
        RotateAngle();
        ViewTypeToggle();
    }

    private void SpectateView()
    {
        Camera.main.transform.position = targetPlayer.position + Quaternion.Euler(angleX, angleY, 0) * Vector3.back * distance + offset;
        Camera.main.transform.rotation = Quaternion.Euler(angleX, angleY, 0);
    }

    private void FlyingView()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector3 moveDir = new Vector3(horizontal, 0, vertical) * 8f;
        Camera.main.transform.position += Quaternion.Euler(angleX, angleY, 0) * moveDir * Time.deltaTime;
        Camera.main.transform.rotation = Quaternion.Euler(angleX, angleY, 0);
        SelectPlayer();
    }
    
    private void ViewTypeToggle()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            isFlying = !isFlying;
        }
    }

    private void RotateAngle()
    {
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        angleX -= mouseY;
        angleY += mouseX;
    }

    private void SelectPlayer()
    {
        // ��ġ, ũ��, ����, ����
        if (Physics.BoxCast(
            Camera.main.transform.position, // ���� ��ġ
            Vector3.one,                    // �ڽ� ũ�� (������)
            Camera.main.transform.forward,  // BoxCast �������
            out RaycastHit hit,             // Cast �浹 �� �浹 ��ü ��
            Camera.main.transform.rotation, // �ڽ� ȸ�� ����
            100f,                           // BoxCast ����
            1 << gameObject.layer           // ���̾� üũ
            ))
        {
            if (Input.GetMouseButtonDown(0))
            {
                targetPlayer = hit.transform;
                isFlying = false;
            }
        }
    }

    private void FindTargetPlayer()
    {
        
    }
}
