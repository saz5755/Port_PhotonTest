using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;

public class KillLogManager : MonoBehaviour
{
    private static KillLogManager instance;

    public static KillLogManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<KillLogManager>();
            return instance;
        }
    }

    [SerializeField]
    private Transform logParent;
    private GameObject logPrefab;

    private void Awake()
    {
        logPrefab = Resources.Load<GameObject>("Prefabs/KillLog");
    }

    public void AddLog(string killer, string victim)
    {
        KillLog log = Instantiate(logPrefab, logParent).GetComponent<KillLog>();
        log.SetLog(killer, victim);
    }
}
