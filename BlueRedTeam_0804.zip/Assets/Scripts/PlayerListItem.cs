using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Realtime;

public class PlayerListItem : MonoBehaviour
{
    [SerializeField] private GameObject isReady;
    [SerializeField] private Text txtNickname;


    private bool readyCheck;
    public void Refresh(Player player)
    {
        txtNickname.text = player.NickName;
    }

    private void Awake()
    {
        isReady.SetActive(false);   
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F5))
        {
            readyCheck = !readyCheck;
            isReady.SetActive(readyCheck);
        }
    }




}
