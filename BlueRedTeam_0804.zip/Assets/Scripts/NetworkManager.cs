using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;


public class NetworkManager : MonoBehaviour
{
    private static NetworkManager instance;

    public static NetworkManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<NetworkManager>();
            return instance;
        }
    }

    private Dictionary<string, RoomInfo> roomList = new Dictionary<string, RoomInfo>();

    private Dictionary<string, Player> playerList = new Dictionary<string, Player>();

    private void Awake()
    {
        PhotonNetwork.ConnectUsingSettings(); // ������ �ߴ��� ���ߴ��� Ȯ�� ����.
    }

    //test�� 
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F3))
        {
            foreach (var player in playerList)
            {
                Debug.Log($" �濡 �ִ� �ο��� : {player.Value.NickName}");
            }
        }
    }

    public void SetNickname(string nickname) // photon ��Ʈ��ũ�� �� �г� �����ϱ�
    {
        PhotonNetwork.NickName = nickname;
        PhotonNetwork.JoinLobby();
        
    }

    public void RoomListUpdate(List<RoomInfo> data)
    {
        for (int i = 0; i < data.Count; i++)
        {
            if (data[i].RemovedFromList)
            {
                roomList.Remove(data[i].Name); // ������ ���ؼ� key���� ��� ���ܽ����ش�.
            }
            else
            {
                if (roomList.ContainsKey(data[i].Name)) // �������̶�� Key���� �����ϴ��� Ȯ���ϱ�
                {
                    roomList[data[i].Name] = data[i];
                }
                else
                {
                    roomList.Add(data[i].Name,data[i]);
                    
                }
            }
            
        }
        UIManager.Instance.RoomListUIRefresh(roomList);
    }

    // 
    public bool AlreadyExistRoomName(string roomName)
    {
        return roomList.ContainsKey(roomName);
    }

    public void CreateRoom(string roomName, byte maxPlayerCount)
    {
        RoomOptions option = new RoomOptions();
        option.MaxPlayers = maxPlayerCount;
        PhotonNetwork.CreateRoom(roomName, option);
    }

    public void ClearRoom()
    {
        roomList.Clear();
    }
    public void LeftRoom()
    {
        PhotonNetwork.LeaveRoom();
    }

    public void ClearPlayerList()
    {
        playerList.Clear();
    }

    public void AddPlayer(Player player)
    {
        if (!playerList.ContainsKey(player.NickName))
        {
            playerList.Add(player.NickName, player);
        }
    }
    public void RemovePlayer(Player player)
    {
        if (playerList.ContainsKey(player.NickName))
        {
            playerList.Remove(player.NickName);
        }
    }

    public void RefreshPlayer(Player player)
    {
        if (playerList.ContainsKey(player.NickName))
        {
            playerList[player.NickName] = player;
        }
        else
        {
            AddPlayer(player);
        }
    }
}
