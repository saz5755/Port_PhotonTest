using Photon.Realtime;

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    private static UIManager instance;

    public static UIManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<UIManager>();
            return instance;
        } 
    }

    private Dictionary<string, RoomInfo> roomList = new Dictionary<string, RoomInfo>();

    [Header("*** ū ����")]
    [SerializeField] private GameObject areaConnectingUI;
    [SerializeField] private GameObject areaNicknameSettingUI;
    [SerializeField] private GameObject areaRoomListUI;
    [SerializeField] private GameObject areaCreateRoomUI;
    [SerializeField] private GameObject areaRoomUI;

    [Header("*** �г��� �Է� ���� UI")]
    [Space(20)]
    [SerializeField] private InputField inputNickname;
    [SerializeField] private Button btnNicknameSubmit;

    [Header("*** �� ��� ���� UI")]
    [Space(20)]
    [SerializeField] private Button btnOpenCreateRoom;
    [SerializeField] private Transform roomListParent;
    private GameObject roomListPrefab;
    private List<RoomListItem> roomListObjects = new List<RoomListItem>();

    [Header("*** �� ���� ���� UI")]
    [Space(20)]
    [SerializeField] private InputField inputRoomName;
    [SerializeField] private Slider sliderMaxPlayerCount;
    [SerializeField] private Button btnCreate;

    [Header("*** �� ���� UI")]
    [Space(20)]
    [SerializeField] private Button btnLeftRoom;
    [SerializeField] private Transform redPlayerListParent;
    [SerializeField] private Transform bluePlayerListParent;

    private GameObject playerListPrefab;

    private List<PlayerListItem> redPlayerListObjects = new List<PlayerListItem>();
    private List<PlayerListItem> bluePlayerListObjects = new List<PlayerListItem>();
    private void Awake()
    {
        roomListPrefab = Resources.Load<GameObject>("Prefabs/RoomListItem");
        InitNicknameUI();
        InitRoomListUI();
        InitCreateRoomUI();
        InitRoomUI();
        InitializeSetting();
        
    }

    public void ConnectedToServer()
    {
        areaConnectingUI.SetActive(false);
        areaNicknameSettingUI.SetActive(true);
    }

    private void InitializeSetting()
    {
        areaConnectingUI.SetActive(true);
        areaNicknameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(false);
        areaCreateRoomUI.SetActive(false);
        areaRoomUI.SetActive(false);
    }

    private void InitNicknameUI()
    {
        btnNicknameSubmit.onClick.AddListener(SetNickname); // Ŭ�������� � �̺�Ʈ�� ����� ������?
    }

    private void InitRoomListUI()
    {
        btnOpenCreateRoom.onClick.AddListener(OpenCreateRoomUI); // �� ����� UI ����
    }

    private void InitCreateRoomUI()
    {
        btnCreate.onClick.AddListener(CreateRoom); // �� �����ϱ�, �� ��� �����, �� �ȿ� �� UI �ѱ�
    }

    private void InitRoomUI()
    {
        playerListPrefab = Resources.Load<GameObject>("Prefabs/PlayerListItem");

        for (int i = 0; i < 5; i++)
        {
            PlayerListItem item = Instantiate(playerListPrefab, redPlayerListParent).GetComponent<PlayerListItem>();
            redPlayerListObjects.Add(item);
        }
        for (int i = 0; i < 5; i++)
        {
            PlayerListItem item = Instantiate(playerListPrefab, bluePlayerListParent).GetComponent<PlayerListItem>();
            item.GetComponent<Image>().color = Color.blue;
            bluePlayerListObjects.Add(item);
        }

        btnLeftRoom.onClick.AddListener(LeftRoom);
    }

    private void SetNickname() // �г��� ���� / Network �гۿ� ���ٿ��� ����
    {
        NetworkManager.Instance.SetNickname(inputNickname.text); // �̱��濡 ���� text�� ����
        areaNicknameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(true);
    }

    public void RoomListUIRefresh(Dictionary<string, RoomInfo> roomList)
    {
        for (int i = 0; i < roomListObjects.Count; i++)
        {
            Destroy(roomListObjects[i].gameObject);
        }
        roomListObjects.Clear();
       
        foreach (var room in roomList)
        {
            RoomListItem listItem = Instantiate(roomListPrefab, roomListParent).GetComponent<RoomListItem>();
            listItem.SetListItem(room.Value);
            roomListObjects.Add(listItem);
        }
    }

    private void OpenCreateRoomUI()
    {
        areaCreateRoomUI.SetActive(true);
    }

    private void CreateRoom()
    {
        if (inputRoomName.text == "")
        {
            Debug.Log("�� �̸��� ����ֽ��ϴ�!");
        }
        else
        {
            if (NetworkManager.Instance.AlreadyExistRoomName(inputRoomName.text))
            {
                Debug.Log("�̹� �� ������ ���� ����");
            }
            else
            {
                NetworkManager.Instance.CreateRoom(inputRoomName.text, (byte)sliderMaxPlayerCount.value);
            }
        }
    }

    private void LeftRoom()
    {
        NetworkManager.Instance.LeftRoom();
        areaRoomListUI.SetActive(true);
        areaRoomUI.SetActive(false);
    }

    public void JoinRoom(RoomInfo info)
    {
        areaConnectingUI.SetActive(false);
        areaNicknameSettingUI.SetActive(false);
        areaRoomListUI.SetActive(false);
        areaCreateRoomUI.SetActive(false);
        areaRoomUI.SetActive(true);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F4))
        {
            Debug.Log(Photon.Pun.PhotonNetwork.InRoom);
            Debug.Log(Photon.Pun.PhotonNetwork.InLobby);
        }
    }
}
