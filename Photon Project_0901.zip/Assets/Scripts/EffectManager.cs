using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectManager : MonoBehaviour
{
    private static EffectManager instance;
    public static EffectManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<EffectManager>();
            return instance;
        }
    }

    private GameObject runDustPrefab;

    private void Awake()
    {
        runDustPrefab = Resources.Load<GameObject>("Prefabs/RunDust");
    }

    public void CreateDust(Vector3 position)
    {
        Instantiate(runDustPrefab, position, Quaternion.identity);
    }
}
