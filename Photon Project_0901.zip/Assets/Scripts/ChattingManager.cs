using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Pun;
using Photon.Realtime;

public class ChattingManager : MonoBehaviourPun
{
    private static ChattingManager instance;
    public static ChattingManager Instance
    {
        get
        {
            if (instance == null) instance = FindObjectOfType<ChattingManager>();
            return instance;
        }
    }

    [SerializeField] 
    private Transform chatParent;
    private GameObject chatPrefab;

    private List<GameObject> chatLog = new List<GameObject>();

    [SerializeField] private InputField inputContent;

    public bool isWriting = false;

    private void Awake()
    {
        chatPrefab = Resources.Load<GameObject>("Prefabs/ChatMessage");
    }

    [PunRPC]
    public void AddChat(Player player, string content)
    {
        GameObject chat = Instantiate(chatPrefab, chatParent);
        chat.GetComponent<ChatMessage>().Init(player, content);
        
        chatLog.Add(chat);
        StartCoroutine(AutoScroll());
    }

    IEnumerator AutoScroll()
    {
        yield return null;
        RectTransform viewPort = chatParent.parent.GetComponent<RectTransform>();
        RectTransform content = chatParent.GetComponent<RectTransform>();

        float y = content.rect.height - viewPort.rect.height;

        content.anchoredPosition = new Vector2(0, y);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (isWriting)
            {
                if(inputContent.text != "")
                {
                    photonView.RPC("AddChat", RpcTarget.All, PhotonNetwork.LocalPlayer, inputContent.text);

                }
            }
            inputContent.text = "";
            isWriting = !isWriting;
            inputContent.gameObject.SetActive(isWriting);
            if (isWriting)
            {
                inputContent.ActivateInputField();
            }
        }
    }
}
