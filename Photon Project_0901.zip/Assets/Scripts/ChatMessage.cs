using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Pun;
using Photon.Realtime;

public class ChatMessage : MonoBehaviour
{
    string[] slangList = new string[]
    {
        "�ù�", "����"
    };

    [SerializeField] private Text txtContent;
    
    public void Init(Player player, string content)
    {
        for (int i = 0; i < slangList.Length; i++)
        {
            if(content.IndexOf(slangList[i]) != -1)
            {
                content = content.Replace(slangList[i],string.Concat(System.Linq.Enumerable.Repeat("*", slangList[i].Length)));
            }
        }

        txtContent.text = $"{player.NickName} : {content}";
        if (PhotonNetwork.CurrentRoom.CustomProperties["isStart"].Equals(true))
        {
            if (player.CustomProperties["myTeam"].Equals("Red"))
            {
                txtContent.color = new Color(.76f, .11f, .23f);
            }
            else
            {
                txtContent.color = new Color(.11f, .23f, .76f);
            }
        }
    }
}
