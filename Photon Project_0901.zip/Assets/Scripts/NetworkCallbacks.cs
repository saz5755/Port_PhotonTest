using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Photon.Pun;
using Photon.Realtime;

public class NetworkCallbacks : MonoBehaviourPunCallbacks
{
    // 9:42 NetworkManager �� ����

    // �̱��� �ȸ���. ��û�� �ϸ� ��.

    public override void OnConnectedToMaster() // 1.������ ���� �Ϸ� -> 2. UIManager���� �г� �Է�â ������ �ؾߵ�.
    {
        if (PhotonNetwork.NickName == "") // ���� ó�� ���� ��
        {
            PhotonNetwork.LocalPlayer.SetCustomProperties(new ExitGames.Client.Photon.Hashtable()
            {
                {"isReady", false },
                {"myTeam", "Red" },
                {"isDead", false },
                {"killCount", 0 }
            });
            UIManager.Instance.ConnectedToServer();
        }
        else
        {
            NetworkManager.Instance.ClearRoom();
            PhotonNetwork.JoinLobby();
        }
    }

    public override void OnJoinedLobby()
    {
        //Debug.Log("�κ� ���� �Ϸ�"); // �κ� �����ϴ� ���ÿ� �� ������ �޾ƿ��� �ȴ�.
    }

    public override void OnJoinedRoom()
    {
        NetworkManager.Instance.ClearPlayerList();
        foreach(var player in PhotonNetwork.CurrentRoom.Players.Values)
        {
            NetworkManager.Instance.AddPlayer(player);
        }
        UIManager.Instance.JoinRoom(PhotonNetwork.CurrentRoom);
    }

    public override void OnPlayerEnteredRoom(Player player)
    {
        NetworkManager.Instance.AddPlayer(player);
    }

    public override void OnPlayerLeftRoom(Player player)
    {
        NetworkManager.Instance.RemovePlayer(player);
    }

    public override void OnLeftRoom()
    {
        NetworkManager.Instance.SetProperties("isReady", false);
    }

    public override void OnRoomListUpdate(List<RoomInfo> roomList)
    {
        NetworkManager.Instance.RoomListUpdate(roomList);
    }

    public override void OnPlayerPropertiesUpdate(Player targetPlayer, ExitGames.Client.Photon.Hashtable changedProps)
    {
        //Debug.Log($"{targetPlayer.NickName}\n{changedProps}");
        NetworkManager.Instance.RefreshPlayer(targetPlayer);
    }

    public override void OnRoomPropertiesUpdate(ExitGames.Client.Photon.Hashtable propertiesThatChanged)
    {
        if (propertiesThatChanged["isStart"] != null)
        {
            if (propertiesThatChanged["isStart"].Equals(true))
            {
                SceneController.Instance.LoadScene("InGameMap2", false);
                SceneController.Instance.LoadScene("InGameUIScene", true);
                SceneController.Instance.LoadScene("InGameModuleScene", true);
            }
        }
    }
}
